import { env } from "cloudflare:workers";
import { getAppSession } from "../../../lib/session";
import { scopedDoctorId } from "../../../lib/doctor-directory";

type ExportRow = {
  patient_username: string;
  doctor_id: string;
  fhir_bundle_json: string;
  consent_status: string | null;
};

export async function GET(request: Request) {
  const session = await getAppSession(request);
  if (!session)
    return Response.json({ error: "Sign in required." }, { status: 401 });
  const intakeId = Number(new URL(request.url).searchParams.get("intakeId"));
  if (!Number.isInteger(intakeId) || intakeId < 1)
    return Response.json({ error: "Valid intake required." }, { status: 400 });

  const row = await env.DB.prepare(
    `SELECT p.patient_username, p.doctor_id, w.fhir_bundle_json,
      (SELECT status FROM consent_records c WHERE c.intake_id = p.id
       ORDER BY c.id DESC LIMIT 1) AS consent_status
     FROM patient_intakes p
     JOIN clinical_workflow_records w ON w.intake_id = p.id
     WHERE p.id = ?`,
  ).bind(intakeId).first<ExportRow>();
  const doctorId = session.role === "doctor" ? scopedDoctorId(session.username) : null;
  const allowed = row && (
    session.role === "admin" ||
    (session.role === "patient" && row.patient_username === session.username) ||
    (session.role === "doctor" && (!doctorId || row.doctor_id === doctorId))
  );
  if (!allowed)
    return Response.json({ error: "FHIR record not found." }, { status: 404 });
  if (row.consent_status !== "granted")
    return Response.json({ error: "Active patient consent is required for FHIR export." }, { status: 403 });

  let bundle: unknown;
  try { bundle = JSON.parse(row.fhir_bundle_json); }
  catch { return Response.json({ error: "Stored FHIR record is invalid." }, { status: 500 }); }
  const validation = validateBundle(bundle);
  if (!validation.valid)
    return Response.json({ error: "FHIR structural validation failed.", issues: validation.issues }, { status: 422 });

  await env.DB.prepare(
    `INSERT INTO audit_events (
      intake_id, actor_username, actor_role, action, resource_type, resource_id, detail_json
    ) VALUES (?, ?, ?, 'fhir-bundle.exported', 'Bundle', ?, ?)`,
  ).bind(intakeId, session.username, session.role, `ayurdoc-intake-${intakeId}`,
    JSON.stringify({ format: "application/fhir+json", structuralValidation: "passed" })).run();

  return new Response(JSON.stringify(bundle, null, 2), {
    headers: {
      "Content-Type": "application/fhir+json; charset=utf-8",
      "Content-Disposition": `attachment; filename="ayurdoc-intake-${intakeId}-fhir.json"`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "X-AyurDoc-FHIR-Check": "structural-pass",
    },
  });
}

function validateBundle(value: unknown) {
  const issues: string[] = [];
  if (!value || typeof value !== "object") issues.push("Bundle must be an object.");
  const bundle = (value ?? {}) as { resourceType?: unknown; type?: unknown; entry?: unknown };
  if (bundle.resourceType !== "Bundle") issues.push("resourceType must be Bundle.");
  if (bundle.type !== "document") issues.push("Bundle type must be document.");
  if (!Array.isArray(bundle.entry) || bundle.entry.length < 3) issues.push("Bundle entries are incomplete.");
  const first = Array.isArray(bundle.entry) ? bundle.entry[0] as { resource?: { resourceType?: unknown } } : null;
  if (first?.resource?.resourceType !== "Composition") issues.push("A document Bundle must start with Composition.");
  return { valid: issues.length === 0, issues };
}
