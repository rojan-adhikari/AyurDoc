export type ClinicalIntakeSource = {
  intakeId: number;
  patientUsername: string;
  fullName: string;
  age: number;
  sex: string;
  department: string;
  doctorId: string;
  doctorName: string;
  language: string;
  complaint: string;
  onset: string;
  symptoms: string;
  conditions: string;
  allergies: string;
  narrative?: string;
  documentName?: string;
  documentType?: string;
  documentFeedback?: string;
  answers?: Record<string, string[]>;
  notes?: Record<string, string>;
  consentedAt: string;
};

const RED_FLAG_RULES: Array<{ code: string; pattern: RegExp; label: string }> = [
  { code: "RF-BREATHING", pattern: /breathing difficulty|shortness of breath|सांस|மூச்சு/i, label: "Breathing difficulty" },
  { code: "RF-NEURO", pattern: /faint|confusion|seizure|sudden weakness|speech|face change|बेहोश|வலிப்பு/i, label: "Acute neurological warning sign" },
  { code: "RF-BLEED", pattern: /heavy bleeding|blood in vomit|blood in stool|रक्तस्राव|இரத்த/i, label: "Possible significant bleeding" },
  { code: "RF-PAIN", pattern: /rapidly worsening pain|severe chest|crushing chest|கடுமையான வலி/i, label: "Severe or rapidly worsening pain" },
  { code: "RF-DEHYDRATION", pattern: /severe dehydration|very low urine|reduced urination|निर्जलीकरण/i, label: "Possible dehydration or reduced urine output" },
];

function uuidReference() {
  return `urn:uuid:${crypto.randomUUID()}`;
}

export function createClinicalWorkflow(source: ClinicalIntakeSource) {
  const searchable = [
    source.complaint,
    source.symptoms,
    source.narrative,
    ...Object.values(source.answers ?? {}).flat(),
    ...Object.values(source.notes ?? {}),
  ].join(" | ");
  const redFlags = RED_FLAG_RULES.filter((rule) => rule.pattern.test(searchable)).map(
    ({ code, label }) => ({ code, label, source: "patient-reported" }),
  );
  const required = [
    source.fullName,
    source.age,
    source.sex,
    source.department,
    source.doctorId,
    source.complaint,
    source.onset,
    source.symptoms,
    source.conditions,
    source.allergies,
    source.consentedAt,
  ];
  const answeredRequired = required.filter((value) => String(value ?? "").trim()).length;
  const completenessScore = Math.round((answeredRequired / required.length) * 100);
  const focusedPathway = Object.entries(source.answers ?? {})
    .filter(([key]) => key.endsWith("_pathway"))
    .flatMap(([, values]) => values);
  const structured = {
    schemaVersion: "ayurdoc-clinical-v1",
    recordId: `clinical-${source.intakeId}`,
    source: "patient-entered-and-machine-structured",
    subject: {
      localPatientId: source.patientUsername,
      name: source.fullName,
      age: source.age,
      sex: source.sex,
    },
    encounter: {
      intakeId: source.intakeId,
      language: source.language,
      department: source.department,
      assignedPractitioner: { id: source.doctorId, name: source.doctorName },
      consentedAt: source.consentedAt,
    },
    history: {
      chiefComplaint: source.complaint,
      onsetAndCourse: source.onset,
      associatedAndAyurvedicHistory: source.symptoms,
      pastConditions: source.conditions,
      medicinesAndAllergies: source.allergies,
      patientNarrative: source.narrative ?? "",
      questionnaireAnswers: source.answers ?? {},
      answerNotes: source.notes ?? {},
    },
    documentEvidence: source.documentName
      ? {
          fileName: source.documentName,
          classifiedType: source.documentType || "Medical record",
          assistedReview: source.documentFeedback || "Pending physician review",
          verificationStatus: "unverified",
        }
      : null,
    triage: {
      level: redFlags.length ? "priority-review" : "routine-review",
      redFlags,
      disclaimer: "Decision support only; a licensed clinician must verify all findings.",
    },
    provenance: {
      createdAt: new Date().toISOString(),
      completenessScore,
      humanConfirmationRequired: true,
    },
  };

  const physicianSummary = [
    `${source.fullName}, ${source.age}-year-old ${source.sex.toLowerCase()}, reports ${source.complaint.toLowerCase()} (${source.onset.toLowerCase()}).`,
    focusedPathway.length ? `Complaint-specific findings: ${focusedPathway.join(", ")}.` : "No complaint-specific pathway finding was recorded.",
    `Associated and Ayurvedic history: ${source.symptoms}.`,
    `Known conditions: ${source.conditions}. Medicines/allergies: ${source.allergies}.`,
    redFlags.length
      ? `PRIORITY: ${redFlags.map((item) => item.label).join(", ")}; verify immediately.`
      : "No configured emergency warning sign was selected; clinician verification remains required.",
    source.documentName
      ? `Attached evidence: ${source.documentName} (${source.documentType || "medical record"}); extracted content is unverified.`
      : "No previous medical document was attached.",
  ].join("\n");

  const patientRef = uuidReference();
  const encounterRef = uuidReference();
  const compositionRef = uuidReference();
  const questionnaireRef = uuidReference();
  const fhirBundle = {
    resourceType: "Bundle",
    id: `ayurdoc-intake-${source.intakeId}`,
    type: "document",
    timestamp: new Date().toISOString(),
    identifier: { system: "https://ayurdoc.medzone.in/intakes", value: String(source.intakeId) },
    entry: [
      {
        fullUrl: compositionRef,
        resource: {
          resourceType: "Composition",
          id: `composition-${source.intakeId}`,
          status: "preliminary",
          type: { text: "Clinical intake summary" },
          subject: { reference: patientRef },
          encounter: { reference: encounterRef },
          date: new Date().toISOString(),
          author: [{ reference: `Practitioner/${source.doctorId}`, display: source.doctorName }],
          title: "AyurDoc patient-entered clinical intake",
          section: [
            { title: "Chief complaint", text: { status: "generated", div: `<div xmlns=\"http://www.w3.org/1999/xhtml\">${escapeFhirText(source.complaint)}</div>` } },
            { title: "Clinical summary", text: { status: "generated", div: `<div xmlns=\"http://www.w3.org/1999/xhtml\">${escapeFhirText(physicianSummary)}</div>` } },
          ],
        },
      },
      {
        fullUrl: patientRef,
        resource: {
          resourceType: "Patient",
          id: `patient-${source.intakeId}`,
          identifier: [{ system: "https://ayurdoc.medzone.in/patients", value: source.patientUsername }],
          name: [{ text: source.fullName }],
          gender: source.sex === "Male" ? "male" : source.sex === "Female" ? "female" : "unknown",
        },
      },
      {
        fullUrl: encounterRef,
        resource: {
          resourceType: "Encounter",
          id: `encounter-${source.intakeId}`,
          status: "planned",
          class: { code: "AMB", display: "ambulatory" },
          subject: { reference: patientRef },
          serviceType: { text: source.department },
          participant: [{ individual: { reference: `Practitioner/${source.doctorId}`, display: source.doctorName } }],
        },
      },
      {
        fullUrl: questionnaireRef,
        resource: {
          resourceType: "QuestionnaireResponse",
          id: `questionnaire-${source.intakeId}`,
          status: "completed",
          subject: { reference: patientRef },
          encounter: { reference: encounterRef },
          authored: source.consentedAt,
          item: Object.entries(source.answers ?? {}).map(([linkId, values]) => ({
            linkId,
            answer: values.map((value) => ({ valueString: value })),
          })),
        },
      },
      ...redFlags.map((flag, index) => ({
        fullUrl: uuidReference(),
        resource: {
          resourceType: "Flag",
          id: `flag-${source.intakeId}-${index + 1}`,
          status: "active",
          category: [{ text: "Clinical safety" }],
          code: { coding: [{ system: "https://ayurdoc.medzone.in/red-flags", code: flag.code }], text: flag.label },
          subject: { reference: patientRef },
        },
      })),
    ],
  };

  return { structured, physicianSummary, fhirBundle, redFlags, completenessScore };
}

function escapeFhirText(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
