# AyurDoc — SIH 2026 Clinical Platform

AyurDoc is a full-stack, multilingual patient–Vaidya coordination application. It supports patient and doctor portals, an administration control centre, Ayurveda-focused clinical intake, voice-to-Vaidya messages, appointments, browser video rooms, ABHA profiles, document review, FHIR previews, emergency/bed workflows, blood-bank workflows, consent, audit records, and physician-verified PDF reports delivered by email.

## Requirements

- Node.js 22.13 or newer
- npm
- Chrome or Microsoft Edge recommended for speech recognition
- Microphone and camera permission for voice/video features

## Run locally

1. Extract the ZIP and open a terminal inside the `AyurDoc` folder.
2. Install dependencies with `npm install`.
3. Optional: copy `.dev.vars.example` to `.dev.vars` and enter a Resend API key and verified sender address. This enables real Gmail OTP and physician-report email delivery.
4. Start the application with `npm run dev`.
5. Open the local address displayed in the terminal, normally `http://localhost:5173`.

The development server provisions local Cloudflare-compatible D1 and R2 storage for structured records and uploaded files. Local data is separate from the publicly hosted AyurDoc database.

## Demo accounts

All demo passwords are `123456`.

### Patients

`patient`, `rojan`, `karan`, `sachin`, `gaurav`, `deepak`, `dharani`

### Nine department Vaidyas

| Username | Doctor | Department |
| --- | --- | --- |
| `ananyasharma` | Dr. Ananya Sharma | Kayachikitsa |
| `rohandas` | Dr. Rohan Das | Twacha Roga & Dermatology |
| `vikramsingh` | Dr. Vikram Singh | Shalya Tantra |
| `farahkhan` | Dr. Farah Khan | Prasuti Tantra & Stri Roga |
| `ayeshajoseph` | Dr. Ayesha Joseph | Shalakya Tantra |
| `aditirao` | Dr. Aditi Rao | Kaumarabhritya / Bala Roga |
| `naveenpatil` | Dr. Naveen Patil | Panchakarma & Rehabilitation |
| `anjaliverma` | Dr. Anjali Verma | Swasthavritta & Yoga |
| `arunalal` | Dr. Aruna Lal | Manasa Roga |

### Hospital-wide supervisor

- Username: `doctor`
- Password: `123456`
- Access: all patient clinical histories across all assigned Vaidyas

### Administrator

- Username: `admin`
- Password: `123456`
- Open from the shield icon on the login page. Administration opens in a separate tab.

## Email configuration

Create `.dev.vars` with:

```text
RESEND_API_KEY=your_resend_api_key
RESEND_FROM_EMAIL=AyurDoc <reports@your-verified-domain.com>
```

Do not commit or share `.dev.vars`. Resend requires the sender domain to be verified before it can deliver reports to arbitrary patient addresses. Without these settings, every other module continues to work and clinical confirmation reports that email delivery is not configured.

## Included modules

- Patient registration with Gmail OTP, government-ID upload and admin approval
- Doctor credentialing application and administrator verification
- ABHA profile and verification status
- English, Hindi and Tamil interface support
- Ayurvedic clinical intake with editable/deletable patient records
- Voice-to-Vaidya audio, browser captions and multilingual summary routing
- Nine-department Vaidya directory and appointment booking
- Patient/doctor video consultation rooms
- Patient EHR, physician edit/confirm/reject workflow and clarification requests
- Professional PDF report emailed after physician confirmation
- Medical-document upload and assisted review feedback
- FHIR Bundle preview, consent records and audit trail
- Emergency/bed request and blood-bank/donation workflows
- AyurAI guided triage with text, speech input, spoken replies and references
- Administration dashboard for accounts, credentials, ABHA, records and inventory

## Production build

Run `npm run build`.

The application targets a Cloudflare Workers-compatible environment and uses D1 for structured data and R2 for uploaded documents/audio.

## Clinical safety

AyurAI provides preliminary routing, general safety information and consultation preparation. It does not provide a final diagnosis or prescribe treatment. The Vaidya remains responsible for reviewing and confirming clinical information.

Med Zone · AyurDoc
